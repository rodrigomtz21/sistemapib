<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use ZipArchive;
class DataController extends Controller
{
    public function save_image(Request $request)
    {   
        $data = $request->all();
        $data = urldecode($data['imageData']);
        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);
        $name = 'gallery/mapa'.rand(0, 100).'.png';
        file_put_contents($name, $data);
        //chmod($name, 0664);
        DB::table('gallery')->insertGetId(
            ['nombre' => $name]
        );
    }
    public function actividades(Request $request)
    {   
        $data = $request->all();
        if ($data['base']==1) {
            $data['base'] = 'pib_precios_constantes';
        }elseif($data['base']==2){
            $data['base'] = 'pib_precios_corrientes';
        }
    	$actividades=DB::table($data['base'])->select('Tipo')->distinct()->orderBy('Tipo')->get();
    	return response()->json(['actividades' => $actividades], 200);
    }
    public function coverturas(Request $request)
    {
    	$data = $request->all();
        if ($data['base']==1) {
            $data['base'] = 'pib_precios_constantes';
        }elseif($data['base']==2){
            $data['base'] = 'pib_precios_corrientes';
        }
    	$coverturas = DB::table($data['base'])->select('Sector')->distinct()->where('Tipo', '=', $data['actividad'])->orderBy('Sector')->get();
        //dd($coverturas);
    	return response()->json(['coverturas' => $coverturas], 200);
    }

    public function subsectores(Request $request){
        $data = $request->all();
        if ($data['base']==1) {
            $data['base'] = 'pib_precios_constantes';
        }elseif($data['base']==2){
            $data['base'] = 'pib_precios_corrientes';
        }
         $subsectores = DB::table($data['base'])->select('Subsector')->distinct()->where('Sector', '=', $data['covertura'])->orderBy('Subsector')->get();
         return response()->json(['subsectores' => $subsectores], 200);
    }
    public function years(Request $request){
        $data = $request->all();
        if ($data['base']==1) {
            $data['base'] = 'pib_precios_constantes';
        }elseif($data['base']==2){
            $data['base'] = 'pib_precios_corrientes';
        }
        $years = $cabeceras = DB::select("SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name   = '".$data['base']."' AND column_name != 'NOM_ENT' AND column_name != 'Tipo' AND column_name != 'cve_ent' AND column_name != 'id' AND column_name != 'Sector' AND column_name != 'Subsector' AND column_name != '2003'");
        return response()->json(['years' => $years], 200);
    }
    public function years_whole(Request $request){
        $data = $request->all();
        if ($data['base']==1) {
            $data['base'] = 'pib_precios_constantes';
        }elseif($data['base']==2){
            $data['base'] = 'pib_precios_corrientes';
        }
        
        $years = $cabeceras = DB::select("SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name   = '".$data['base']."' AND column_name != 'NOM_ENT' AND column_name != 'Tipo' AND column_name != 'cve_ent' AND column_name != 'id' AND column_name != 'Sector' AND column_name != 'Subsector'");
         return response()->json(['years' => $years], 200);
    }
    public function images(){
        $images = DB::table('gallery')->select('id', 'nombre')->get();
        return response()->json(['images' => $images]);
    }
    public function truncate_gallery(){
        $entidades = DB::table('gallery')->truncate();
        $files = glob('gallery/*'); // obtiene todos los archivos
        foreach($files as $file){
          if(is_file($file)) // si se trata de un archivo
            unlink($file); // lo elimina
        }
        if (file_exists('gallery.zip')) {
            unlink('gallery.zip');
        }
        
        return response()->json(['truncate' => 'ok']);
    }
    public function download_gallery(){
        $zipper = new \Chumper\Zipper\Zipper;
        $files = glob('gallery/*');
        $zipper->make('gallery.zip')->add($files);

        $zipper->close();
        return response()->download(public_path('gallery.zip'));
    }
    public function entidades(){
        $entidades = DB::table('mge')->select('nom_ent', 'cve_ent', 'clave_region', 'latitud', 'longitud')->orderBy('cve_ent')->distinct()->get();
        return response()->json(['entidades' => $entidades]);
    }

    public function entidades_by_region(Request $request){
        $data = $request->all();
        $entidades = DB::table('mge')->select('id', 'nom_ent', 'cve_ent', 'clave_region')->orderBy('cve_ent')->where('clave_region', '=', $data['id'])->get();
        return response()->json(['entidades' => $entidades]);
    }
    public function regiones(){
        $regiones = DB::table('regiones')->select('Nombre', 'clave', 'latitud', 'longitud')->orderBy('clave')->distinct()->get();
        return response()->json(['regiones' => $regiones]);
    }

    public function tabla_excel(Request $request){
        $data = $request->all();
        dd($data);
        //return $tabla = \View::make('tabla')->with(['title_string'=>$data['title_string'], 'title_valores'=>$data['title_valores'], 'headers'=>$data['headers'], 'data'=>$data['data'], 'clases'=>$data['clases']]);
        return $tabla = \View::make('tabla')->with(['data'=>$data]);
    }
}
